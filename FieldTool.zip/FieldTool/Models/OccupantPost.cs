﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FieldTool.Models
{
    public class OccupantPost
    {
        public int OccupantId { get; set; }
        public int CaseId { get; set; }
        public string Occupant_FirstName { get; set; }
        public string Occupant_MiddleName { get; set; }
        public string Occupant_LastName { get; set; }
        public string OccupantAddress { get; set; }
        public string Occupant_ExtentInjury { get; set; }
        public string Occupant_DriverPassenger { get; set; }
        public Nullable<int> Vehicle_Number { get; set; }
        public string Occupant_PedestrianVehicle { get; set; }
        public string Occupant_Injuerynature { get; set; }
        public string Occupant_RemovedBy { get; set; }
        public Nullable<int> Age { get; set; }
        public Nullable<int> Sex { get; set; }
    }
}
