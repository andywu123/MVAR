﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FieldTool.Models
{
    public class reportFormDataPost
    {
        public AccidentReportPost accidentReport { get; set; }
        public List<VehiclePost> vehicles { get; set; }
        public List<OccupantPost> occupants { get; set; }
        public List<WitnessPost> witnesses { get; set; }
        public List<ChargePost> charges { get; set; }
    }
}
