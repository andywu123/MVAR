﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FieldTool.Models
{
    public class WitnessPost
    {
        public int WitnessId { get; set; }
        public decimal CaseId { get; set; }
        public string WitnessName { get; set; }
        public string WitnessPhone { get; set; }
        public string WitnessAddress { get; set; }
    }
}
