﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FieldTool.Models
{
    public class ChargePost
    {
        public int CHARGEId { get; set; }
        public int CaseId { get; set; }
        public Nullable<int> CityEmpl_Charge { get; set; }
        public Nullable<decimal> ChargeAmount { get; set; }
        public Nullable<int> Summons_No { get; set; }
        public string Trial_Time { get; set; }
    }
}
