﻿

$.fn.dataTableExt.ofnSearch['domain'] = function (a) {
    var x = a.split('/')[0];
    return x;
}