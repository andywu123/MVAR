﻿var CD = CD || {};

CD.forms = {

}

$(document).ready(function () {
    CD.Reports.init();
    CD.canvasDraw.init();
    CD.intersection.init();
    CD.AccidentForm.init();
    CD.ViewAccidentForm.init();
});